import { checkout, polar, portal, webhooks } from "@polar-sh/better-auth";
import { Polar } from "@polar-sh/sdk";
import * as Sentry from "@sentry/nextjs";
import { betterAuth } from "better-auth";
import {
  captcha,
  createAuthMiddleware,
  customSession,
  magicLink,
} from "better-auth/plugins";
import { github } from "better-auth/social-providers";
import Database from "better-sqlite3";
import { Pool } from "pg";
import { PRODUCTS } from "./product-list";
import { sendEmail } from "./send-mail";

export const polarClient = new Polar({
  accessToken: process.env.POLAR_ACCESS_TOKEN,
  // Use 'sandbox' if you're using the Polar Sandbox environment
  // Remember that access tokens, products, etc. are completely separated between environments.
  // Access tokens obtained in Production are for instance not usable in the Sandbox environment.
  server: process.env.NODE_ENV === "production" ? "production" : "sandbox",
});

export const auth = betterAuth({
  user: {
    additionalFields: {
      planType: {
        type: "string",
        required: false,
        input: false, // don't allow user to set plan type
      },
      ghSponsorInfo: {
        type: "string",
        required: false,
        input: false, // don't allow user to set role
      },
    },
  },
  emailVerification: {
    sendOnSignUp: true,
    autoSignInAfterVerification: true,
    async sendVerificationEmail({ user, url }) {
      await sendEmail({
        to: user.email,
        template: "verifyEmail",
        props: { url, name: user.name },
      });
    },
  },
  emailAndPassword: {
    enabled: true,
    requireEmailVerification: true,
    autoSignIn: true,
  },
  socialProviders: {
    github: {
      clientId: process.env.AUTH_GITHUB_ID as string,
      clientSecret: process.env.AUTH_GITHUB_SECRET as string,
      async getUserInfo(token) {
        // This is a workaround to still re-use the default github provider getUserInfo
        // and still be able to fetch the sponsor info with the token
        return (await github({
          clientId: process.env.AUTH_GITHUB_ID as string,
          clientSecret: process.env.AUTH_GITHUB_SECRET as string,
          async mapProfileToUser() {
            const resSponsor = await fetch(`https://api.github.com/graphql`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token.accessToken}`,
              },
              // organization(login:"TypeCellOS") {
              // user(login:"YousefED") {
              body: JSON.stringify({
                query: `{
                    user(login:"YousefED") {
                      sponsorshipForViewerAsSponsor(activeOnly:false) {
                        isActive,
                        tier {
                          name
                          monthlyPriceInDollars
                        }
                      }
                    }
                  }`,
              }),
            });
            if (resSponsor.ok) {
              // Mock data. TODO: disable and test actial data
              // profile.sponsorInfo = {
              //   isActive: true,
              //   tier: {
              //     name: "test",
              //     monthlyPriceInDollars: 100,
              //   },
              // };
              // use API data:
              const data = await resSponsor.json();
              //// eslint-disable-next-line no-console
              console.log("sponsor data", data);
              // {
              //   "data": {
              //     "user": {
              //       "sponsorshipForViewerAsSponsor": {
              //         "isActive": true,
              //         "tier": {
              //           "name": "$90 a month",
              //           "monthlyPriceInDollars": 90
              //         }
              //       }
              //     }
              //   }
              // }
              const sponsorInfo: null | {
                isActive: boolean;
                tier: {
                  monthlyPriceInDollars: number;
                };
              } = data.data.user.sponsorshipForViewerAsSponsor;
              if (!sponsorInfo?.isActive) {
                return {};
              }
              return {
                ghSponsorInfo: JSON.stringify(sponsorInfo),
              };
            }
            return {};
          },
        }).getUserInfo(token))!;
      },
    },
  },
  // Use SQLite for local development
  database:
    process.env.NODE_ENV === "production" || process.env.POSTGRES_URL
      ? new Pool({
          connectionString: process.env.POSTGRES_URL,
        })
      : new Database("./sqlite.db"),
  plugins: [
    captcha({
      provider: "cloudflare-turnstile",
      secretKey: process.env.TURNSTILE_SECRET_KEY!,
      endpoints: ["/sign-up/email"],
    }),
    customSession(
      async ({ user, session }) => {
        // If they are a GitHub sponsor, use that plan type
        if (user.ghSponsorInfo) {
          const sponsorInfo = JSON.parse(user.ghSponsorInfo);
          return {
            planType:
              sponsorInfo.tier.monthlyPriceInDollars > 100
                ? "business"
                : "starter",
            user,
            session,
          };
        }
        // If not, see if they are subscribed to a Polar product
        // If not, use the free plan
        return {
          planType: user.planType ?? PRODUCTS.free.slug,
          user,
          session,
        };
      },
      {
        // This is really only for type inference
        user: {
          additionalFields: {
            ghSponsorInfo: {
              type: "string",
              required: false,
              input: false, // don't allow user to set role
            },
            planType: {
              type: "string",
              required: false,
              input: false, // don't allow user to set plan type
            },
          },
        },
      },
    ),
    magicLink({
      sendMagicLink: async ({ email, url }) => {
        await sendEmail({
          to: email,
          template: "magicLink",
          props: { url },
        });
      },
    }),
    // Just temporary for testing
    // Serves on http://localhost:3000/api/auth/reference
    // openAPI(),
    polar({
      client: polarClient,
      // Enable automatic Polar Customer creation on signup
      createCustomerOnSignUp: true,
      use: [
        checkout({
          products: [
            {
              productId: PRODUCTS.business.id, // ID of Product from Polar Dashboard
              slug: PRODUCTS.business.slug, // Custom slug for easy reference in Checkout URL, e.g. /checkout/pro
            },
            {
              productId: PRODUCTS["business-yearly"].id,
              slug: PRODUCTS["business-yearly"].slug,
            },
            {
              productId: PRODUCTS.starter.id,
              slug: PRODUCTS.starter.slug,
            },
          ],
          successUrl: "/thanks",
          // Pay-first: allow logged-out checkout. The buyer is reconciled to a
          // BlockNote account by email in the webhook below
          // (resolveUserForCustomer), then emailed a sign-in link.
          authenticatedUsersOnly: false,
        }),
        portal(),
        webhooks({
          secret: process.env.POLAR_WEBHOOK_SECRET as string,
          async onPayload(payload) {
            switch (payload.type) {
              case "subscription.active":
              case "subscription.canceled":
              case "subscription.updated":
              case "subscription.revoked":
              case "subscription.created":
              case "subscription.uncanceled": {
                // Resolve the BlockNote account for this purchase. For pay-first
                // (logged-out) checkouts the customer has no externalId, so this
                // creates/links an account by email and sends a sign-in link.
                const userId = await resolveUserForCustomer(
                  payload.data.customer,
                );
                if (!userId) {
                  return;
                }
                const authContext = await auth.$context;
                if (payload.data.status === "active") {
                  const productId = payload.data.product.id;
                  const planType = Object.values(PRODUCTS).find(
                    (p) => p.id === productId,
                  )?.slug;
                  await authContext.internalAdapter.updateUser(userId, {
                    planType,
                  });
                } else {
                  // No active subscription, so we need to remove the plan type
                  await authContext.internalAdapter.updateUser(userId, {
                    planType: null,
                  });
                }
              }
            }
          },
        }),
      ],
    }),
  ],
  onAPIError: {
    onError: (error) => {
      Sentry.captureException(error, {
        tags: { source: "better-auth" },
        level: "fatal",
      });
    },
  },
  hooks: {
    after: createAuthMiddleware(async (ctx) => {
      if (
        ctx.path === "/magic-link/verify" ||
        ctx.path === "/verify-email" ||
        ctx.path === "/sign-in/social"
      ) {
        // After verifying email, send them a welcome email
        const newSession = ctx.context.newSession;
        if (newSession) {
          const oneMinuteAgo = new Date(Date.now() - 60 * 1000);
          if (
            ctx.path === "/magic-link/verify" &&
            newSession.user.createdAt < oneMinuteAgo
          ) {
            // magic link is for an account that was created more than a minute ago, so just a normal sign in
            // no need to send welcome email
            return false;
          }
          // await sendEmail({
          //   to: newSession.user.email,
          //   template: "welcome",
          //   props: {
          //     name: newSession.user.name,
          //   },
          // });
          return;
        }
      }
    }),
  },
});

// For "pay-first" checkouts the buyer may not have an account yet: the Polar
// customer has no externalId because they checked out while logged out. Resolve
// the BlockNote user for a Polar customer — creating one keyed on the checkout
// email when needed — so the purchase can be provisioned and the buyer gets
// access (via a sign-in link) to the account holding their new plan.
async function resolveUserForCustomer(customer: {
  id: string;
  externalId?: string | null;
  email?: string | null;
  name?: string | null;
}): Promise<string | null> {
  // Authenticated purchase: the customer is already linked to a user.
  if (customer.externalId) {
    return customer.externalId;
  }
  const email = customer.email;
  if (!email) {
    return null;
  }

  const authContext = await auth.$context;
  const existing = await authContext.internalAdapter.findUserByEmail(email);
  if (existing?.user) {
    // Existing account, but this logged-out purchase created an unlinked Polar
    // customer — link it so the buyer's subscription is found.
    await linkPolarCustomer(customer.id, existing.user.id);
    return existing.user.id;
  }

  try {
    const created = await authContext.internalAdapter.createUser({
      email,
      name: customer.name || email,
      emailVerified: false,
    });
    // Link the Polar customer to the new account. Subscription and
    // customer-portal lookups resolve a user's customer by externalId, so
    // without this the buyer couldn't access or manage the plan they bought.
    await linkPolarCustomer(customer.id, created.id);
    // New account → email a sign-in link so they can access the plan they
    // just bought. A mail failure must not block provisioning.
    try {
      await auth.api.signInMagicLink({
        body: { email, callbackURL: "/pricing" },
        headers: new Headers(),
      });
    } catch (err) {
      Sentry.captureException(err);
    }
    return created.id;
  } catch (err) {
    // A concurrent webhook for the same purchase may have created the user
    // first (email is unique). Re-fetch instead of failing provisioning.
    const retry = await authContext.internalAdapter.findUserByEmail(email);
    if (retry?.user) {
      await linkPolarCustomer(customer.id, retry.user.id);
      return retry.user.id;
    }
    throw err;
  }
}

// Link a Polar customer to a BlockNote user by setting the customer's
// externalId. Subscription and customer-portal lookups resolve a user's Polar
// customer by `externalId === user.id`, so a logged-out (pay-first) purchase
// must be linked here or the buyer can't access/manage their subscription.
// Best-effort: a failure is reported but must not block provisioning the plan,
// and subsequent subscription events retry the link via the same path.
async function linkPolarCustomer(customerId: string, userId: string) {
  try {
    await polarClient.customers.update({
      id: customerId,
      customerUpdate: { externalId: userId },
    });
  } catch (err) {
    Sentry.captureException(err);
  }
}
