// AUTO-GENERATED FILE, DO NOT EDIT DIRECTLY
import react from "@vitejs/plugin-react";
import * as fs from "fs";
import * as path from "path";
import { defineConfig } from "vite";
// https://vitejs.dev/config/
export default defineConfig(((conf: { command: string }) => ({
  plugins: [react()],
  optimizeDeps: {},
  build: {
    sourcemap: true,
  },
  resolve: {
    alias:
      conf.command === "build" ||
      !fs.existsSync(path.resolve(__dirname, "../../packages/core/src"))
        ? {}
        : ({
            // The repo-wide alias for the shared test-utils directory (private,
            // so it only resolves inside the monorepo). Harmless for examples
            // that don't use it.
            "@shared": path.resolve(__dirname, "../../../shared/"),
            // Comment out the lines below to load a built version of blocknote
            // or, keep as is to load live from sources with live reload working
            "@blocknote/core": path.resolve(
              __dirname,
              "../../packages/core/src/",
            ),
            "@blocknote/react": path.resolve(
              __dirname,
              "../../packages/react/src/",
            ),
          } as any),
  },
})) as Parameters<typeof defineConfig>[0]);
